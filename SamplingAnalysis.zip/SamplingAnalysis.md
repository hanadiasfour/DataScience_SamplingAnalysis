# Statistical Analysis of a Normally Distributed Population

Welcome to this Jupyter notebook where we create some statistical analysis of a normally distributed population.insightful.

### Importing libraries


```python
import numpy as np
import matplotlib.pyplot as plt
```

### Setting the random seed as: 1210209


```python
np.random.seed(1210209)
```

### Generating a normally distributed population size 10,000,000 with mean = 1,500 and standard deviation = 700


```python
population = np.random.normal(size= 10000000, scale= 700, loc= 1500)
```

### Histogram for the population showing the normal distribution of the data


```python
#creating the histogram for the population size 10,000,000
plt.figure(figsize=(5, 4))
plt.hist(population, bins=50, color='pink', edgecolor='black')
plt.title("Histogram of population")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()
```


    
![png](output_8_0.png)
    


### Taking random samples with sizes 10 / 100 / 1,000 / 10,000 from the total population.


```python
#sizes to sample from the population:
sample_sizes = [10, 100, 1000, 10000]

#selecting the random samples in this loop
samples = {}
for size in sample_sizes:
    samples[size] = np.random.choice(population, size=size, replace=False)

```

### Histogram for sample size 10 


```python
#creating the histogram for the sample size 10
plt.figure(figsize=(4, 3))
plt.hist(samples[10], bins=20, color='lightgrey', edgecolor='black')
plt.title("Histogram of Sample Size 10")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()
```


    
![png](output_12_0.png)
    


### Histogram for sample size 100 


```python
#creating the histogram for the sample size 100
plt.figure(figsize=(4, 3))
plt.hist(samples[100], bins=30, color='grey', edgecolor='black')
plt.title("Histogram of Sample Size 100")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()
```


    
![png](output_14_0.png)
    


### Histogram for sample size 1,000 


```python
#creating the histogram for the sample size 1,000
plt.figure(figsize=(4, 3))
plt.hist(samples[1000], bins=40, color='skyblue', edgecolor='black')
plt.title("Histogram of Sample Size 1,000")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()
```


    
![png](output_16_0.png)
    


### Histogram for sample size 10,000 


```python
#creating the histogram for the sample size 10,000
plt.figure(figsize=(5, 4))
plt.hist(samples[10000], bins=50, color='lightblue', edgecolor='black')
plt.title("Histogram of Sample Size 10,000")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()
```


    
![png](output_18_0.png)
    


## By comparing the samples and population histograms, we can answer the following:

### - What is the relation between the sample size and the sampling error?
        The larger a sample becomes, the smaller its sampling error is.
    
### - Which sample is more representative of the population? justify your answer.
        The largest sample, size 10,000, is the best representative out of the four samples. Moreover, when increasing the sample size, its data variation becomes broader, giving a more accurate representation of the entire population and decreasing its sampling error, as mentioned earlier.
    
        You can verify this by comparing the sample histograms together. The smallest sample has an almost linear shape since each value has equal frequencies of 1 or 2. Then, by increasing the sample size, the graphs became more normally distributed, like the population.
      
      
## Setting the representative sample as the sample of size 10,000:


```python
representative_sample = samples[10000]
```


```python
plt.figure(figsize=(5, 4))
plt.hist(representative_sample, bins=50, color='lightgreen', edgecolor='black')
plt.title("Histogram of Representative Sample Size 10,000")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()
```


    
![png](output_21_0.png)
    


## By analyzing the representative sample:

### a) Is the random sample nomally distributed?



```python
#calculating sample mean
representative_sample_mean = representative_sample.mean()
representative_sample_mean
```




    1507.2366783631737



   **Yes, the random sample is normally distributed since the graph shows a bell-shaped curve with the majority of data points clustered around the mean, which indicates its symmetry and behavior as normally distributed data.**
   
   
   ### b) Value that 50% of the data is below:


```python
median_value = np.median(representative_sample)
median_value
```




    1501.7997342780845



   ### c) Value that 75% of the data is below:


```python
percentile_75 = np.percentile(representative_sample, 75)
percentile_75
```




    1984.051980937823



   ### d) Value that 25% of the data is below:


```python
percentile_25 = np.percentile(representative_sample, 25)
percentile_25
```




    1028.7297251681664



### e) What are the values calculated in b, c, and d are statistically called ?
    - Median (50% value)
    - Third quartile (75% value)    
    - First quartile (25% value)
